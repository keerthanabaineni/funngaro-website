import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ArrowRight, Sparkles, Wallet, ShieldCheck, Rocket, TrendingUp, Users } from "lucide-react";
import heroTeens from "@/assets/hero-teens.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Funngro — Get paid by brands you already love" },
      { name: "description", content: "India's #1 earning app for teens. 70 lakh young Indians earn rupees from 5,000+ brands through gigs, content & referrals. Free forever, paid in UPI." },
      { property: "og:title", content: "Funngro — India's earning app for teens" },
      { property: "og:description", content: "70 lakh+ young Indians earning with India's biggest brands. Paid in UPI." },
    ],
  }),
  component: Index,
});

const stats = [
  { value: "70L+", label: "Young Indians earning" },
  { value: "5,000+", label: "Real brands" },
  { value: "1,000+", label: "Live projects" },
  { value: "₹100Cr+", label: "Paid out in UPI" },
];

const categories = [
  { tag: "BFSI", brand: "ICICI" },
  { tag: "FINTECH", brand: "Paytm" },
  { tag: "D2C", brand: "Novio" },
  { tag: "RESEARCH", brand: "Toluna" },
  { tag: "MOBILITY", brand: "CarDekho" },
  { tag: "D2C", brand: "Lifelong" },
  { tag: "BFSI", brand: "Kotak" },
  { tag: "FINTECH", brand: "LXME" },
  { tag: "RESEARCH", brand: "Nielsen" },
  { tag: "FINTECH", brand: "Mpokket" },
];

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[image:var(--gradient-hero)]" />
        <div className="absolute -top-32 left-1/2 -z-10 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-primary/20 blur-3xl" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-28">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
              <Sparkles className="h-3.5 w-3.5" /> As seen on Shark Tank India · S2
            </span>
            <h1 className="mt-5 text-4xl font-black leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
              Get paid by brands <span className="text-primary">you already love.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted-foreground">
              70 lakh young Indians work with India's biggest brands on Funngro — brand promotion, content, referrals, sampling, surveys. Paid in UPI. Free, forever.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Button size="lg" className="rounded-full bg-primary px-6 font-semibold text-primary-foreground hover:bg-primary/90">
                Download app <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Link to="/teens" className="text-sm font-semibold text-foreground underline-offset-4 hover:underline">
                See how it works →
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap gap-8">
              {stats.slice(0, 3).map((s) => (
                <div key={s.label}>
                  <div className="text-2xl font-black text-primary">{s.value}</div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <div className="absolute -inset-4 -z-10 rounded-3xl bg-[image:var(--gradient-accent)] opacity-30 blur-2xl" />
            <img
              src={heroTeens}
              alt="Young Indian teens earning with Funngro"
              width={1280}
              height={960}
              className="rounded-3xl border border-border shadow-[var(--shadow-glow)]"
            />
          </div>
        </div>
      </section>

      {/* Brand wall */}
      <section className="border-y border-border/60 bg-card/30 py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-center text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">· The brand wall ·</p>
          <h2 className="mt-3 text-center text-3xl font-bold tracking-tight sm:text-4xl">Real brands. Real rupees. Every day.</h2>
          <p className="mx-auto mt-3 max-w-2xl text-center text-muted-foreground">
            From the bank that holds your salary to the apps on your home screen — they all work with Funngro users.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            {categories.map((c, i) => (
              <div key={i} className="rounded-full border border-border bg-background/60 px-4 py-2 text-sm">
                <span className="mr-2 text-xs font-bold text-primary">{c.tag}</span>
                <span className="font-semibold">{c.brand}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">How Funngro works</h2>
          <p className="mt-3 text-muted-foreground">Three steps from sign-up to UPI payout.</p>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {[
            { icon: Rocket, title: "Pick a project", body: "Choose from 1,000+ live brand gigs — from promotions to surveys." },
            { icon: Sparkles, title: "Do the task", body: "Complete it from your phone. Most gigs take under 30 minutes." },
            { icon: Wallet, title: "Get paid in UPI", body: "Money lands in your UPI account. No hidden fees. Ever." },
          ].map((step, i) => (
            <div key={step.title} className="group rounded-2xl border border-border bg-card p-6 transition-all hover:-translate-y-1 hover:border-primary/50 hover:shadow-[var(--shadow-glow)]">
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary">
                <step.icon className="h-5 w-5" />
              </div>
              <div className="mt-5 text-xs font-bold uppercase tracking-wider text-muted-foreground">Step {i + 1}</div>
              <h3 className="mt-1 text-xl font-semibold">{step.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{step.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Two CTAs */}
      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
        <div className="grid gap-6 md:grid-cols-2">
          <Link to="/teens" className="group relative overflow-hidden rounded-3xl border border-border bg-card p-8 transition-all hover:border-primary/60">
            <Users className="h-8 w-8 text-primary" />
            <h3 className="mt-4 text-2xl font-bold">I'm a Teen</h3>
            <p className="mt-2 text-muted-foreground">Start earning real money from brands you already use. Free to join.</p>
            <div className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary">
              Start earning <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </div>
          </Link>
          <Link to="/companies" className="group relative overflow-hidden rounded-3xl border border-border bg-card p-8 transition-all hover:border-primary/60">
            <TrendingUp className="h-8 w-8 text-primary" />
            <h3 className="mt-4 text-2xl font-bold">I'm a Brand</h3>
            <p className="mt-2 text-muted-foreground">Reach 70 lakh Gen-Z Indians with measurable, performance-based campaigns.</p>
            <div className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary">
              Launch a campaign <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </div>
          </Link>
        </div>
      </section>

      {/* Trust */}
      <section className="border-t border-border/60 bg-card/30 py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center gap-4 text-center">
            <ShieldCheck className="h-8 w-8 text-primary" />
            <h3 className="text-2xl font-bold tracking-tight">Safe. Verified. Built for India.</h3>
            <p className="max-w-2xl text-muted-foreground">
              Backed by SucSEED. Every brand on Funngro is vetted. Every payout is verified through UPI.
              Rated ★ 4.2 by 3,702+ earning teens on Play Store.
            </p>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
