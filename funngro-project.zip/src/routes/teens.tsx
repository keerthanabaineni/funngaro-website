import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ArrowRight, Wallet, Smartphone, Trophy, Gift, ShieldCheck, Clock } from "lucide-react";
import heroTeens from "@/assets/hero-teens.jpg";

export const Route = createFileRoute("/teens")({
  head: () => ({
    meta: [
      { title: "For Teens — Earn from your phone with Funngro" },
      { name: "description", content: "Funngro for teens: earn real money from 5,000+ Indian brands through gigs, surveys, content & referrals. Paid in UPI, no investment, free forever." },
      { property: "og:title", content: "Funngro for Teens — Earn from your phone" },
      { property: "og:description", content: "Join 70 lakh Indian teens earning real rupees in UPI from brands they love." },
    ],
  }),
  component: TeensPage,
});

const perks = [
  { icon: Wallet, title: "Instant UPI payouts", body: "Money lands straight in your UPI app — no waiting, no minimum threshold tricks." },
  { icon: Smartphone, title: "100% mobile-first", body: "Built for your phone. Most gigs are done in under 30 minutes between classes." },
  { icon: Trophy, title: "Level up your CV", body: "Earn certificates from real brands like ICICI, Paytm & CarDekho — perfect for college apps." },
  { icon: Gift, title: "Free, forever", body: "No subscription. No hidden fees. No investment. Sign up free and start earning." },
  { icon: ShieldCheck, title: "Parent-safe", body: "Every brand and payout is verified. Built specifically for India's 13-19 age group." },
  { icon: Clock, title: "Work on your time", body: "Pick gigs that fit around school, coaching, and life. You decide what and when." },
];

const ways = [
  { tag: "01", title: "Brand promotions", body: "Share, post & talk about brands you already use on Insta & WhatsApp." },
  { tag: "02", title: "Content creation", body: "Create reels, reviews & UGC for D2C & fintech brands." },
  { tag: "03", title: "Surveys & research", body: "Share your opinion for global research firms like Nielsen & Toluna." },
  { tag: "04", title: "Referrals", body: "Refer apps, banks & loans to friends and family — earn per signup." },
  { tag: "05", title: "Product sampling", body: "Try new products and share honest feedback. Often you keep the product." },
  { tag: "06", title: "Mini-gigs", body: "Quick micro-tasks that pay ₹20–₹500 each. Stack them up." },
];

function TeensPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <section className="relative overflow-hidden bg-[image:var(--gradient-hero)]">
        <div className="absolute right-0 top-0 -z-0 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div className="relative z-10">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
              For Teens · 13–19
            </span>
            <h1 className="mt-5 text-4xl font-black leading-tight tracking-tight sm:text-5xl lg:text-6xl">
              Your phone is now a <span className="text-primary">paycheque.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted-foreground">
              Join 70 lakh+ Indian teens earning real money from real brands.
              Pocket-money, gadget funds, college savings — all from your phone. Paid in UPI. No investment, ever.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button size="lg" className="rounded-full bg-primary px-6 font-semibold text-primary-foreground hover:bg-primary/90">
                Download the app <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" className="rounded-full">
                See live gigs
              </Button>
            </div>
          </div>
          <img
            src={heroTeens}
            alt="Indian teens earning on Funngro"
            width={1280}
            height={960}
            className="rounded-3xl border border-border shadow-[var(--shadow-glow)]"
          />
        </div>
      </section>

      {/* Ways to earn */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-primary">Ways to earn</p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">Six ways to turn screen time into rupees.</h2>
        </div>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {ways.map((w) => (
            <div key={w.title} className="rounded-2xl border border-border bg-card p-6 transition-all hover:-translate-y-1 hover:border-primary/50">
              <div className="text-sm font-bold text-primary">{w.tag}</div>
              <h3 className="mt-2 text-lg font-semibold">{w.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{w.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Perks */}
      <section className="border-t border-border/60 bg-card/30 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Built for India's Gen-Z.</h2>
            <p className="mt-3 text-muted-foreground">Why 70 lakh teens chose Funngro as their first paycheque.</p>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {perks.map((p) => (
              <div key={p.title} className="rounded-2xl border border-border bg-background p-6">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary">
                  <p.icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 text-lg font-semibold">{p.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{p.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="mx-auto max-w-5xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-3xl border border-primary/40 bg-[image:var(--gradient-hero)] p-10 text-center shadow-[var(--shadow-glow)] sm:p-14">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Your first ₹500 is one tap away.
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Free to download. Free to use. Paid in UPI.
          </p>
          <Button size="lg" className="mt-7 rounded-full bg-primary px-7 font-semibold text-primary-foreground hover:bg-primary/90">
            Download Funngro <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
