import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ArrowRight, Target, BarChart3, Zap, Users, CheckCircle2, Globe2 } from "lucide-react";
import heroCompanies from "@/assets/hero-companies.jpg";

export const Route = createFileRoute("/companies")({
  head: () => ({
    meta: [
      { title: "For Brands — Reach 70 lakh Gen-Z Indians on Funngro" },
      { name: "description", content: "Launch performance marketing, UGC, sampling, surveys & referral campaigns with 70 lakh+ verified young Indians. Pay per outcome. Trusted by ICICI, Paytm, Kotak, CarDekho, Nielsen." },
      { property: "og:title", content: "Funngro for Brands — India's Gen-Z growth engine" },
      { property: "og:description", content: "Performance-based access to 70 lakh young Indians. Backed by SucSEED." },
    ],
  }),
  component: CompaniesPage,
});

const offerings = [
  { icon: Target, title: "Performance marketing", body: "CPI, CPL, CPA — only pay for verified outcomes. No upfront media spend." },
  { icon: Users, title: "UGC at scale", body: "Source 100s of authentic reels, reviews & testimonials in days, not months." },
  { icon: BarChart3, title: "Research & surveys", body: "Talk to verified Gen-Z respondents across 600+ Indian cities." },
  { icon: Zap, title: "Product sampling", body: "Get your product into the hands of your ideal user and capture honest reviews." },
];

const logos = ["ICICI", "Paytm", "Kotak", "CarDekho", "Nielsen", "Toluna", "LXME", "Mpokket", "Lifelong", "Novio"];

const why = [
  "70 lakh+ verified young Indian users",
  "Reach Tier 1, 2, 3 & rural India",
  "Pay only for verified outcomes",
  "Full-funnel: awareness → conversion",
  "Built-in fraud & bot protection",
  "Dedicated campaign manager",
];

function CompaniesPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <section className="relative overflow-hidden bg-[image:var(--gradient-hero)]">
        <div className="absolute left-0 top-0 -z-0 h-96 w-96 rounded-full bg-primary/15 blur-3xl" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div className="relative z-10">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
              For Brands · Pay-per-outcome
            </span>
            <h1 className="mt-5 text-4xl font-black leading-tight tracking-tight sm:text-5xl lg:text-6xl">
              India's Gen-Z, <span className="text-primary">on tap.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted-foreground">
              Funngro is the youth growth engine for India's biggest brands. Activate 70 lakh+ verified young Indians for promotions, UGC, sampling, surveys & referrals — all performance-priced.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button size="lg" className="rounded-full bg-primary px-6 font-semibold text-primary-foreground hover:bg-primary/90">
                Book a demo <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" className="rounded-full">
                Download deck
              </Button>
            </div>
            <div className="mt-10 grid grid-cols-3 gap-6">
              <Stat value="70L+" label="Reach" />
              <Stat value="600+" label="Indian cities" />
              <Stat value="5,000+" label="Brands trust us" />
            </div>
          </div>
          <img
            src={heroCompanies}
            alt="Funngro brand dashboard reaching young Indians"
            width={1280}
            height={960}
            className="rounded-3xl border border-border shadow-[var(--shadow-glow)]"
          />
        </div>
      </section>

      {/* Logo wall */}
      <section className="border-y border-border/60 bg-card/30 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-center text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">Trusted by India's most loved brands</p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
            {logos.map((l) => (
              <span key={l} className="text-lg font-bold tracking-tight text-muted-foreground/80">{l}</span>
            ))}
          </div>
        </div>
      </section>

      {/* Offerings */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-primary">What you can run</p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">Four campaign types. One performance contract.</h2>
        </div>
        <div className="mt-12 grid gap-5 sm:grid-cols-2">
          {offerings.map((o) => (
            <div key={o.title} className="group rounded-2xl border border-border bg-card p-7 transition-all hover:-translate-y-1 hover:border-primary/50 hover:shadow-[var(--shadow-glow)]">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary">
                <o.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-5 text-xl font-semibold">{o.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{o.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Why */}
      <section className="border-t border-border/60 bg-card/30 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <Globe2 className="h-10 w-10 text-primary" />
              <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">
                The youth distribution network India was missing.
              </h2>
              <p className="mt-4 text-muted-foreground">
                Funngro replaces fragmented influencer agencies, ad-network bots, and panel companies with one verified, performance-priced layer for India's youth.
              </p>
            </div>
            <ul className="grid gap-3 sm:grid-cols-2">
              {why.map((w) => (
                <li key={w} className="flex items-start gap-3 rounded-xl border border-border bg-background p-4">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <span className="text-sm font-medium">{w}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-5xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-3xl border border-primary/40 bg-[image:var(--gradient-hero)] p-10 text-center shadow-[var(--shadow-glow)] sm:p-14">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Launch your first campaign in 7 days.
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Tell us your goal — we'll come back with a benchmarked, pay-per-outcome proposal.
          </p>
          <Button size="lg" className="mt-7 rounded-full bg-primary px-7 font-semibold text-primary-foreground hover:bg-primary/90">
            Book a 30-min demo <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div>
      <div className="text-2xl font-black text-primary">{value}</div>
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}
