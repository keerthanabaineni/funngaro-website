import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-[image:var(--gradient-accent)] font-black text-primary-foreground">F</span>
          <span className="text-lg font-bold tracking-tight">Funngro</span>
        </Link>
        <nav className="hidden items-center gap-7 text-sm font-medium md:flex">
          <Link to="/teens" className="text-muted-foreground transition-colors hover:text-foreground [&.active]:text-primary">For Teens</Link>
          <Link to="/companies" className="text-muted-foreground transition-colors hover:text-foreground [&.active]:text-primary">For Companies</Link>
          <a href="#how" className="text-muted-foreground transition-colors hover:text-foreground">How it works</a>
        </nav>
        <Button variant="default" className="rounded-full bg-primary font-semibold text-primary-foreground hover:bg-primary/90">
          Download app
        </Button>
      </div>
    </header>
  );
}
