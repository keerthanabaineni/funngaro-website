import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 bg-card/40">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4 lg:px-8">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-[image:var(--gradient-accent)] font-black text-primary-foreground">F</span>
            <span className="text-lg font-bold">Funngro</span>
          </div>
          <p className="mt-3 max-w-sm text-sm text-muted-foreground">
            India's first earning platform built for teens. 70 lakh+ young Indians already earning with the brands they love.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Product</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/teens" className="hover:text-foreground">For Teens</Link></li>
            <li><Link to="/companies" className="hover:text-foreground">For Companies</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Company</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><a href="https://www.instagram.com/funngro/" className="hover:text-foreground">Instagram</a></li>
            <li><a href="https://www.funngro.com" className="hover:text-foreground">funngro.com</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/60 py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Funngro. Backed by SucSEED. As seen on Shark Tank India.
      </div>
    </footer>
  );
}
